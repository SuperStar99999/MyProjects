package company.myapplication;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.ViewPager;
import android.util.Base64;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.Console;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Calendar;

public class MainActivity extends FragmentActivity {
    final static String ScreenName = "FEA_AUB";
    ArrayList<String> al_text = new ArrayList<>();

    String[] strUrlImg; //URLs for Image Or Video
    String[] strUrlQR;  //URLs for QR image
    int[] nType;        //Tablet Type



    String[] strWeek = {
            "Sunday", "Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"
    };

    String[] strMonth = {
            "January","February","March","April","May","June","July","August","September","October","November","December"
    };

    String strImgUrl = "http://www.json-generator.com/api/json/get/bPctVjJGgi?indent=2";    //URL for JSONArray

    TextView tx_time;       //TextView for Date

    ViewPager mViewPager;   //Main Image/Video Slider
    AndroidImageAdapter adapterView;    //Slider Adapter

    ViewPager mViewPagerTweet;   //Main Tweets Slider
    AndroidTweetAdapter adapterViewTweet;    //Slider Adapter

    int currentPage = -1;    //Indicate Current Slider
    int NUM_PAGES = 0;      //Total Images and Videos
    int NUM_TWEETS = 0;
    boolean isStart = true;

    Handler timerHanderTweet;
    Handler timerHandler;
    Handler urlHandler;
    //----------------Change view every 5 second-------------------------------
    final Runnable Update = new Runnable() {
        public void run() {
            if(currentPage != -1)
                currentPage = mViewPager.getCurrentItem();
            currentPage ++;
            if(currentPage == NUM_PAGES)
                currentPage = 0;
            mViewPager.setCurrentItem(currentPage, true);   //Set Slider
            if(currentPage > 0) {
                if ((strUrlImg[currentPage - 1].contains(".png")) || (strUrlImg[currentPage - 1].contains(".jpg")) || (strUrlImg[currentPage - 1].contains(".bmp")))
                    timerHandler.postDelayed(Update, 5000);     //If Slider show image, update after 5 sec
                else {
                    int nDuration = adapterView.getVideoDuration(); //Get Video Duration
                    timerHandler.postDelayed(Update, nDuration + 5000);    //If Slider show Video, update after finish video
                }
            }
            else
                timerHandler.postDelayed(Update, 5000);     //If Slider show image, update after 5 sec
        }
    };
    final Runnable UpdateTweet = new Runnable() {
        public void run() {
            int nIndex = mViewPagerTweet.getCurrentItem();
            nIndex ++;
            if(nIndex == NUM_TWEETS)
                nIndex = 0;
            mViewPagerTweet.setCurrentItem(nIndex);
            urlHandler.postDelayed(UpdateTweet,10000);
        }
    };
    final Runnable UpdateUrl = new Runnable() {
        public void run() {
            makeJsonArrayRequest();
            urlHandler.postDelayed(UpdateUrl,15000);
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tx_time = (TextView) findViewById(R.id.tx_time);    //TextView for Date
        mViewPagerTweet = (ViewPager) findViewById(R.id.txt_tweet);
        adapterViewTweet = new AndroidTweetAdapter(MainActivity.this);

        //--------------------Set Date-------------------------
        Calendar c = Calendar.getInstance();
        int dayOfWeek = c.get(Calendar.DAY_OF_WEEK);
        tx_time.setText(strWeek[dayOfWeek-1] + " " +c.get(Calendar.DAY_OF_MONTH) + " " + strMonth[ c.get(Calendar.MONTH)] + " "+  c.get(Calendar.YEAR) );

        //------Init View and Resources------
        getJsonData();
        downloadTweets();
    }

    //-----------------Send Request and Initialize Viewpager-----------
    public void getJsonData(){
        mViewPager = (ViewPager) findViewById(R.id.viewPageAndroid);
        adapterView = new AndroidImageAdapter(this);
        makeJsonArrayRequest();
        urlHandler = new Handler();
        urlHandler.postDelayed(UpdateUrl,60000);
    }

    //-----------------Requesting JSONARRAY--------------
    private void makeJsonArrayRequest() {
        Log.i("SendRequest","Sending");
        RequestQueue queue = Volley.newRequestQueue(MainActivity.this);
        String encodedUrl = null;
        try {
            encodedUrl = URLEncoder.encode(strImgUrl, "UTF-8");
        } catch (UnsupportedEncodingException ignored) {
            // Can be safely ignored because UTF-8 is always supported
        }
        JsonArrayRequest req = new JsonArrayRequest(strImgUrl,new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                Log.i("SendRequest","parsing");
                        parseJSON(response);    //If success getting JSONArray, Parse JsonArray
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        });
        // Adding request to request queue
        queue.add(req);
        Log.i("SendRequest","Sent");
    }

    //-------------------Parsing JSONARRAY--------------
    private void parseJSON(JSONArray response){

        //Alloc Array(Image, QR, TabletId)
        strUrlImg = new String[response.length()];
        strUrlQR = new String[response.length()];
        nType = new int[response.length()];
        NUM_PAGES = response.length() + 1;          //Get Total count of JsonObject
        for(int i = 0; i < response.length(); i++){
            try {
                JSONObject jresponse = response.getJSONObject(i);
                String encodedUrl = jresponse.getString("Picture_Path");
                try {
                    strUrlImg[i] = URLEncoder.encode(encodedUrl, "UTF-8");
                } catch (UnsupportedEncodingException ignored) {
                    // Can be safely ignored because UTF-8 is always supported
                }

                strUrlQR[i] = jresponse.getString("QR_code");
                nType[i] = jresponse.getInt("Tablet_ID");
                Log.i("Info",strUrlImg[i]);
                Log.i("InfoQR",strUrlQR[i]);

            }catch (JSONException e) {
                e.printStackTrace();
            }
        }
        if(isStart) {
//            filterTablet_ID();
            adapterView.setResource(strUrlImg, strUrlQR);     //Init ViewPagerAdapter
            mViewPager.setAdapter(adapterView);     //Set ViewPager
            timerHandler = new Handler();
            timerHandler.postDelayed(Update, 0);     //Timer to update the slider automatically
            isStart = false;
        }
        else {
//            filterTablet_ID();
//            adapterView.setResource(strUrlImg, strUrlQR);     //Init ViewPagerAdapter
            adapterView.notifyDataSetChanged();
        }
    }
    public void filterTablet_ID(){
        String[] strImgTemp;
        String[] strQrTemp;
        int nCount = 0;
        for(int i = 0; i < nType.length; i ++)
        {
            if(nType[i]==1)
                nCount++;
        }
        strImgTemp = new String[nCount];
        strQrTemp = new String[nCount];
        int j = 0;
        for (int i = 0; i < nType.length; i ++)
        {
            if(nType[i] == 1)
            {
                strImgTemp[j] = strUrlImg[i];
                strQrTemp[j] = strUrlQR[i];
                j++;
            }
        }
        strUrlImg = new String[nCount];
        strUrlQR = new String[nCount];

        strUrlImg = strImgTemp;
        strUrlQR = strQrTemp;
    }

    //--------------------------TWEET VIEW------------------------

    public void downloadTweets() {
        ConnectivityManager connMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();

        if (networkInfo != null && networkInfo.isConnected()) {
            new DownloadTwitterTask().execute(ScreenName);
        } else {
            Toast.makeText(getApplicationContext(),"Please check your internet connection",Toast.LENGTH_SHORT).show();
        }
    }

    // Uses an AsyncTask to download a Twitter user's timeline
    private class DownloadTwitterTask extends AsyncTask<String, Void, String> {
        final static String CONSUMER_KEY = "nW88XLuFSI9DEfHOX2tpleHbR";
        final static String CONSUMER_SECRET = "hCg3QClZ1iLR13D3IeMvebESKmakIelp4vwFUICuj6HAfNNCer";
        final static String TwitterTokenURL = "https://api.twitter.com/oauth2/token";
        final static String TwitterStreamURL = "https://api.twitter.com/1.1/statuses/user_timeline.json?screen_name=";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... screenNames) {
            String result = null;

            if (screenNames.length > 0) {
                result = getTwitterStream(screenNames[0]);
            }
            return result;
        }

        // onPostExecute convert the JSON results into a Twitter object (which is an Array list of tweets
        @Override
        protected void onPostExecute(String result) {
            Log.e("result",result);


            try {
                JSONArray jsonArray_data = new JSONArray(result);
                al_text.clear();
                if(jsonArray_data.length() > 10) {
                    for (int i = jsonArray_data.length() - 10; i < jsonArray_data.length(); i++) {

                        JSONObject jsonObject = jsonArray_data.getJSONObject(i);
                        al_text.add(jsonObject.getString("text"));
                    }
                }
                else{
                    for (int i = 0; i < jsonArray_data.length(); i++) {

                        JSONObject jsonObject = jsonArray_data.getJSONObject(i);
                        al_text.add(jsonObject.getString("text"));
                    }
                }
            }catch (Exception e){
                e.printStackTrace();
            }

            // send the tweets to the adapter for rendering
            NUM_TWEETS = al_text.size();
            timerHanderTweet = new Handler();
            adapterViewTweet.setResources(al_text);
            mViewPagerTweet.setAdapter(adapterViewTweet);
            timerHanderTweet.postDelayed(UpdateTweet,10000);
        }


        // convert a JSON authentication object into an Authenticated object
        private Authenticated jsonToAuthenticated(String rawAuthorization) {
            Authenticated auth = null;
            if (rawAuthorization != null && rawAuthorization.length() > 0) {
                try {
                    Gson gson = new Gson();
                    auth = gson.fromJson(rawAuthorization, Authenticated.class);
                } catch (IllegalStateException ex) {
                    // just eat the exception
                }
            }
            return auth;
        }

        private String getResponseBody(HttpRequestBase request) {
            StringBuilder sb = new StringBuilder();
            try {

                DefaultHttpClient httpClient = new DefaultHttpClient(new BasicHttpParams());
                HttpResponse response = httpClient.execute(request);
                int statusCode = response.getStatusLine().getStatusCode();
                String reason = response.getStatusLine().getReasonPhrase();

                if (statusCode == 200) {

                    HttpEntity entity = response.getEntity();
                    InputStream inputStream = entity.getContent();

                    BufferedReader bReader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"), 8);
                    String line = null;
                    while ((line = bReader.readLine()) != null) {
                        sb.append(line);
                    }
                } else {
                    sb.append(reason);
                }
            } catch (UnsupportedEncodingException ex) {
            } catch (ClientProtocolException ex1) {
            } catch (IOException ex2) {
            }
            return sb.toString();
        }

        private String getTwitterStream(String screenName) {
            String results = null;

            // Step 1: Encode consumer key and secret
            try {
                // URL encode the consumer key and secret
                String urlApiKey = URLEncoder.encode(CONSUMER_KEY, "UTF-8");
                String urlApiSecret = URLEncoder.encode(CONSUMER_SECRET, "UTF-8");

                // Concatenate the encoded consumer key, a colon character, and the
                // encoded consumer secret
                String combined = urlApiKey + ":" + urlApiSecret;

                // Base64 encode the string
                String base64Encoded = Base64.encodeToString(combined.getBytes(), Base64.NO_WRAP);

                // Step 2: Obtain a bearer token
                HttpPost httpPost = new HttpPost(TwitterTokenURL);
                httpPost.setHeader("Authorization", "Basic " + base64Encoded);
                httpPost.setHeader("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8");
                httpPost.setEntity(new StringEntity("grant_type=client_credentials"));
                String rawAuthorization = getResponseBody(httpPost);
                Authenticated auth = jsonToAuthenticated(rawAuthorization);

                // Applications should verify that the value associated with the
                // token_type key of the returned object is bearer
                if (auth != null && auth.token_type.equals("bearer")) {

                    // Step 3: Authenticate API requests with bearer token
                    HttpGet httpGet = new HttpGet(TwitterStreamURL + screenName);

                    // construct a normal HTTPS request and include an Authorization
                    // header with the value of Bearer <>
                    httpGet.setHeader("Authorization", "Bearer " + auth.access_token);
                    httpGet.setHeader("Content-Type", "application/json");
                    // update the results with the body of the response
                    results = getResponseBody(httpGet);
                }
            } catch (UnsupportedEncodingException ex) {
            } catch (IllegalStateException ex1) {
            }
            return results;
        }
    }

    boolean doubleBackToExitPressedOnce = false;
    @Override
    public void onBackPressed() {

        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }
        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                doubleBackToExitPressedOnce=false;
            }
        }, 2000);
    }

}
