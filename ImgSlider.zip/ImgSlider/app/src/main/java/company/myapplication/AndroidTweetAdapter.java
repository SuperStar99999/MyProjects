package company.myapplication;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.net.Uri;
import android.support.v4.view.PagerAdapter;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.github.rtoshiro.view.video.FullscreenVideoLayout;
import com.google.zxing.WriterException;
import com.squareup.picasso.Picasso;

import java.io.IOException;
import java.util.ArrayList;

import zh.wang.android.yweathergetter4a.WeatherInfo;
import zh.wang.android.yweathergetter4a.YahooWeather;

/**
 * Created by Jong9 on 4/10/2017.
 */

public class AndroidTweetAdapter extends PagerAdapter {
    Context mContext;
    LayoutInflater mLayoutInflater;
    ArrayList<String> al_text;
    TextView tx_tweet;
    Typeface new_font;  //Custom Font

    public AndroidTweetAdapter(Context context) {
        mContext = context;
        mLayoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        new_font = Typeface.createFromAsset(mContext.getAssets(),"twitterfont.ttf");   //Custom Font
    }

    @Override
    public int getItemPosition(Object object) {
        return POSITION_NONE;
    }

    @Override
    public int getCount() {
        return al_text.size();
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == ((LinearLayout) object);
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        View itemView = mLayoutInflater.inflate(R.layout.adapter_layout, container, false);
        tx_tweet = (TextView) itemView.findViewById(R.id.tv_text);    //Tweets Text
        tx_tweet.setTypeface(new_font);
        tx_tweet.setText(al_text.get(position));
        container.addView(itemView);
        return itemView;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((LinearLayout) object);
    }

    public void setResources(ArrayList<String> al_text)
    {
        this.al_text = al_text;
        Log.i("Count",al_text.size()+"");
    }
}
