package company.myapplication;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.media.MediaPlayer;
import android.net.Uri;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.github.rtoshiro.view.video.FullscreenVideoLayout;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.squareup.picasso.Picasso;

import java.io.IOException;

import zh.wang.android.yweathergetter4a.WeatherInfo;
import zh.wang.android.yweathergetter4a.YahooWeather;
import zh.wang.android.yweathergetter4a.YahooWeatherInfoListener;

import static android.graphics.Color.BLACK;
import static android.graphics.Color.WHITE;

public class AndroidImageAdapter extends PagerAdapter implements YahooWeatherInfoListener {

    private YahooWeather mYahooWeather = YahooWeather.getInstance(5000, true);  //Yahoo Weather Variable
    private WeatherInfo wiToday;
    int nDuration = 0;  //Video Duration
    ImageView imgView, imgQR;   //ImageView for Slider and QR Code
    public FullscreenVideoLayout videoLayout;   //Video Layout
    String[] strUrl;        //URLs for images and videos
    String[] strQr; //URLs for QR_code

    TextView mTvWeather0;   //TextView for Weather
    LinearLayout lytToday;  //ImageView for Weather
    TextView mTvTemp0;

    Context mContext;
    LayoutInflater mLayoutInflater;
    LinearLayout mWeatherInfosLayout;


    public AndroidImageAdapter(Context context) {
        mContext = context;
        mLayoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
//        searchByPlaceName("beirut");
    }

    @Override
    public int getCount() {
        return strUrl.length + 1;
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == ((LinearLayout) object);
    }

    @Override
    public int getItemPosition(Object object) {
        return POSITION_NONE;
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        if(position == 0)
        {
            View itemView = mLayoutInflater.inflate(R.layout.weatherlyt, container, false);
            mTvWeather0 = (TextView) itemView.findViewById(R.id.textview_weather_info_0);    //Weather Text
            lytToday = (LinearLayout) itemView.findViewById(R.id.todaybkg);  //Weather Image
            mTvTemp0 = (TextView) itemView.findViewById(R.id.todaytemp);    //Weather Text

            mWeatherInfosLayout = (LinearLayout) itemView.findViewById(R.id.weather_infos);
            if (wiToday != null) {
                mTvWeather0.setText(wiToday.getCurrentText());
                mTvTemp0.setText(wiToday.getCurrentTemp() + "º");
                if(wiToday.getCurrentText().contains("cloud"))
                {
                    lytToday.setBackgroundResource(R.drawable.cloudbkg);
                }
                else if(wiToday.getCurrentText().contains("rain"))
                {
                    lytToday.setBackgroundResource(R.drawable.rainbkg);
                }
                else if(wiToday.getCurrentText().contains("snow"))
                {
                    lytToday.setBackgroundResource(R.drawable.snowbkg);
                }else //if(wiToday.getCurrentText().contains("Sunny"))
                {
                    lytToday.setBackgroundResource(R.drawable.sunnybkg);
                }

                for (int i = 1; i < 5; i++) {
                    final LinearLayout forecastInfoLayout = (LinearLayout) mLayoutInflater.inflate(R.layout.forecastinfo, null);
                    final TextView tvWeek = (TextView) forecastInfoLayout.findViewById(R.id.textview_forecast_info);
                    final TextView tvTop = (TextView) forecastInfoLayout.findViewById(R.id.textview_forecast_info_top);
                    final TextView tvBottom =  (TextView) forecastInfoLayout.findViewById(R.id.textview_forecast_info_bottom);

                    final WeatherInfo.ForecastInfo forecastInfo = wiToday.getForecastInfoList().get(i);
                    tvWeek.setText("" + forecastInfo.getForecastDate());
                    tvTop.setText(""+forecastInfo.getForecastTempHigh());//+ "\n" +
                    tvBottom.setText(""+forecastInfo.getForecastTempLow());

                    final ImageView ivForecast = (ImageView) forecastInfoLayout.findViewById(R.id.imageview_forecast_info);

                    if(forecastInfo.getForecastText().contains("cloud"))
                    {
                        ivForecast.setImageResource(R.drawable.cloudy);
                    }
                    else if(forecastInfo.getForecastText().contains("rain"))
                    {
                        ivForecast.setImageResource(R.drawable.rain);
                    }
                    else if(forecastInfo.getForecastText().contains("snow"))
                    {
                        ivForecast.setImageResource(R.drawable.snow);
                    }else//                if(forecastInfo.getForecastText().contains("sunny"))
                    {
                        ivForecast.setImageResource(R.drawable.sunny);
                    }
                    mWeatherInfosLayout.addView(forecastInfoLayout);
                }
            }
            container.addView(itemView);
            return itemView;
        }
        else
        {
            View itemView = mLayoutInflater.inflate(R.layout.sliderview, container, false);

            imgView = (ImageView) itemView.findViewById(R.id.imageView);
            imgQR = (ImageView) itemView.findViewById(R.id.imgQR);
            videoLayout = (FullscreenVideoLayout) itemView.findViewById(R.id.videoview);

            try {
                // generate a 150x150 QR code
                Bitmap bm = encodeAsBitmap(strQr[position-1]);
                if (bm != null) {
                    imgQR.setImageBitmap(bm);
                }
            } catch (WriterException e) {
            }

            if ((strUrl[position-1].contains(".png")) || (strUrl[position-1].contains(".jpg")) || (strUrl[position-1].contains(".bmp"))
                ||(strUrl[position-1].contains(".PNG"))||(strUrl[position-1].contains(".JPG"))||(strUrl[position-1].contains(".BMP")))   //If it is a Image
            {
                //---------------Hide Video Layout and show Image and QR layout-------------------
                imgView.setVisibility(View.VISIBLE);
                imgQR.setVisibility(View.VISIBLE);
                videoLayout.setVisibility(View.GONE);
                Picasso.with(mContext).load(strUrl[position-1]).into(imgView);    //Set Image Resource
            } else    //If it is a video
            {
                //---------------Hide Image Layout and show Video and QR layout-------------------
                imgView.setVisibility(View.GONE);
                imgQR.setVisibility(View.VISIBLE);
                videoLayout.setVisibility(View.VISIBLE);
                videoLayout.setActivity((Activity) mContext);
                final Uri videoUri = Uri.parse(strUrl[position-1]);
                try {
                    videoLayout.setVideoURI(videoUri);
                    videoLayout.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {    //If video prepared
                        public void onPrepared(MediaPlayer mp) {
                            videoLayout.start();
                            nDuration = videoLayout.getDuration();
                        }
                    });
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            container.addView(itemView);
            return itemView;
        }
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((LinearLayout) object);
    }

    //Init Image URLs from MainActivity
    public void setResource(String[] strURLs,String[] strQrs){
        strUrl = strURLs;
        strQr = strQrs;
    }

    //Main Fucntion for Generating QR Code
    Bitmap encodeAsBitmap(String str) throws WriterException {
        BitMatrix result;
        try {
            result = new MultiFormatWriter().encode(str,
                    BarcodeFormat.QR_CODE, 150, 150, null);
        } catch (IllegalArgumentException iae) {
            // Unsupported format
            return null;
        }
        int w = result.getWidth();
        int h = result.getHeight();
        int[] pixels = new int[w * h];
        for (int y = 0; y < h; y++) {
            int offset = y * w;
            for (int x = 0; x < w; x++) {
                pixels[offset + x] = result.get(x, y) ? BLACK : WHITE;
            }
        }
        Bitmap bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        bitmap.setPixels(pixels, 0, 150, 0, 0, w, h);
        return bitmap;
    }

    //Return Video Duration
    public int getVideoDuration(){
        return nDuration;
    }

    //--------------Weather Listener-------------------
    @Override
    public void gotWeatherInfo(WeatherInfo weatherInfo, YahooWeather.ErrorType errorType) {
        if (weatherInfo != null) {
            wiToday = weatherInfo;

            mTvWeather0.setText(wiToday.getCurrentText()+"");
            mTvTemp0.setText(wiToday.getCurrentTemp() + "º");

            if(wiToday.getCurrentText().contains("cloud"))
            {
                lytToday.setBackgroundResource(R.drawable.cloudbkg);
            }
            else if(wiToday.getCurrentText().contains("rain"))
            {
                lytToday.setBackgroundResource(R.drawable.rainbkg);
            }
            else if(wiToday.getCurrentText().contains("snow"))
            {
                lytToday.setBackgroundResource(R.drawable.snowbkg);
            }else //if(wiToday.getCurrentText().contains("Sunny"))
            {
                lytToday.setBackgroundResource(R.drawable.sunnybkg);
            }


            for (int i = 1; i < 5; i++) {
                final LinearLayout forecastInfoLayout = (LinearLayout) mLayoutInflater.inflate(R.layout.forecastinfo, null);
                final TextView tvWeek = (TextView) forecastInfoLayout.findViewById(R.id.textview_forecast_info);
                final TextView tvTop = (TextView) forecastInfoLayout.findViewById(R.id.textview_forecast_info_top);
                final TextView tvBottom =  (TextView) forecastInfoLayout.findViewById(R.id.textview_forecast_info_bottom);

                final WeatherInfo.ForecastInfo forecastInfo = wiToday.getForecastInfoList().get(i);
                tvWeek.setText("" + forecastInfo.getForecastDate());
                tvTop.setText(""+forecastInfo.getForecastTempHigh());//+ "\n" +
                tvBottom.setText(""+forecastInfo.getForecastTempLow());

                final ImageView ivForecast = (ImageView) forecastInfoLayout.findViewById(R.id.imageview_forecast_info);

                if(forecastInfo.getForecastText().contains("cloud"))
                {
                    ivForecast.setImageResource(R.drawable.cloudy);
                }
                else if(forecastInfo.getForecastText().contains("rain"))
                {
                    ivForecast.setImageResource(R.drawable.rain);
                }
                else if(forecastInfo.getForecastText().contains("snow"))
                {
                    ivForecast.setImageResource(R.drawable.snow);
                }else//                if(forecastInfo.getForecastText().contains("sunny"))
                {
                    ivForecast.setImageResource(R.drawable.sunny);
                }
                mWeatherInfosLayout.addView(forecastInfoLayout);
            }

        } else {
        }
    }

    private void searchByPlaceName(String location) {
        mYahooWeather.setNeedDownloadIcons(true);
        mYahooWeather.setUnit(YahooWeather.UNIT.CELSIUS);
        mYahooWeather.setSearchMode(YahooWeather.SEARCH_MODE.PLACE_NAME);
        mYahooWeather.queryYahooWeatherByPlaceName(mContext, location, AndroidImageAdapter.this);
    }
}