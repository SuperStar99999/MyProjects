package company.myapplication;

public class Authenticated {
	String token_type;
	String access_token;
}
