package com.company.phonecooler;

public class GlobalVar {
    public static boolean isReminder;
    public static boolean isCelsius;
    public static int nCurrent;
    public static int nStatus;
    GlobalVar(){
        nStatus = -1;
        nCurrent = 0;
        isReminder = true;
        isCelsius = true;
    }
}
