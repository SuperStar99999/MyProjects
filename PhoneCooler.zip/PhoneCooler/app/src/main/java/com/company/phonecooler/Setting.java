package com.company.phonecooler;

import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.Switch;
import android.widget.TextView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.NativeExpressAdView;

public class Setting extends AppCompatActivity {
    AdView adView;
    NativeExpressAdView adView_middle;

    TextView tx_noti, tx_unit, tx_rate, tx_about, tx_version, tx_tmp;
    LinearLayout lyt_noti, lyt_rate, lyt_unit;
    Switch swtch_noti;

    private SharedPreferences.Editor editor;
    private SharedPreferences spSetting;

    Typeface custom_font;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setDisplayShowTitleEnabled(true);

        //-------------------bottom banner-------------------
        adView = (AdView) findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().setRequestAgent("android_studio:ad_template").build();
        adView.loadAd(adRequest);

        //-------------------Middle Admob--------------------
        adView_middle = (NativeExpressAdView)findViewById(R.id.adView_middle);
        String android_id = Settings.Secure.getString(this.getContentResolver(),Settings.Secure.ANDROID_ID);
        AdRequest request = new AdRequest.Builder().addTestDevice(android_id).build();
        adView_middle.loadAd(request);

        this.spSetting = this.getSharedPreferences("BBSettings", 0);
        this.editor = this.spSetting.edit();
        loadSetting();

        get_Resources();
    }

    public void get_Resources() {
        custom_font = Typeface.createFromAsset(getAssets(), "fonts/LinotteRegular.ttf");   //Custom Font

        tx_noti = (TextView) findViewById(R.id.LTextView2);
        tx_unit = (TextView) findViewById(R.id.tx_unit);
        tx_rate = (TextView) findViewById(R.id.tx_rate);
        tx_about = (TextView) findViewById(R.id.tx_about);
        tx_version = (TextView) findViewById(R.id.txt_version);
        tx_tmp = (TextView) findViewById(R.id.temperature_unit);

        tx_noti.setTypeface(custom_font);
        tx_unit.setTypeface(custom_font);
        tx_rate.setTypeface(custom_font);
        tx_about.setTypeface(custom_font);
        tx_version.setTypeface(custom_font);
        tx_tmp.setTypeface(custom_font);
        if(GlobalVar.isCelsius)
            tx_tmp.setText("℃");
        else
            tx_tmp.setText("°F");

        swtch_noti = (Switch) findViewById(R.id.sw_reminder);
        lyt_noti = (LinearLayout) findViewById(R.id.layout_reminder);
        lyt_unit = (LinearLayout) findViewById(R.id.layout_temperature_unit);
        lyt_rate = (LinearLayout) findViewById(R.id.layout_rate);

        swtch_noti.setChecked(GlobalVar.isReminder);
        swtch_noti.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                GlobalVar.isReminder = isChecked;
            }
        });
        lyt_noti.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GlobalVar.isReminder = !GlobalVar.isReminder;
                swtch_noti.setChecked(GlobalVar.isReminder);
            }
        });
        lyt_unit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Dialog dlg_unit = new Dialog(Setting.this);
                dlg_unit.setContentView(R.layout.dl_select_temperature);
                dlg_unit.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

                TextView tx_cancel = (TextView) dlg_unit.findViewById(R.id.text_cancel);
                RadioButton radioCel = (RadioButton) dlg_unit.findViewById(R.id.rd_celsius);
                RadioButton radioFab = (RadioButton) dlg_unit.findViewById(R.id.rd_fahrenheit);
                if(GlobalVar.isCelsius)
                    radioCel.setChecked(true);
                else
                    radioFab.setChecked(true);
                tx_cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dlg_unit.dismiss();
                    }
                });
                radioCel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        GlobalVar.isCelsius = true;
                        tx_tmp.setText("℃");
                        dlg_unit.dismiss();
                    }
                });
                radioFab.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        GlobalVar.isCelsius = false;
                        tx_tmp.setText("°F");
                        dlg_unit.dismiss();
                    }
                });
                dlg_unit.show();
            }
        });
        lyt_rate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uri = Uri.parse("market://details?id=" + getApplicationContext().getPackageName());
                Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
                goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY | Intent.FLAG_ACTIVITY_NEW_DOCUMENT | Intent.FLAG_ACTIVITY_MULTIPLE_TASK);

                try {
                    startActivity(goToMarket);
                } catch (ActivityNotFoundException e) {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + getApplicationContext().getPackageName())));
                }
            }
        });
    }

    public void saveSetting(){
        this.editor.putBoolean("isReminder", GlobalVar.isReminder);
        this.editor.putBoolean("isCelius", GlobalVar.isReminder);
        this.editor.commit();
    }

    public void loadSetting(){
        GlobalVar.isReminder = this.spSetting.getBoolean("isReminder", true);
        GlobalVar.isReminder = this.spSetting.getBoolean("isCelius", true);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        saveSetting();
        this.finish();
        return true;
    }
}
