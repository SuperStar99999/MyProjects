package com.company.phonecooler;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

import java.util.ArrayList;
import java.util.List;

public class Scan extends Activity {
    AdView adView;

    TextView tx_title, tx_scan, tx_trash, tx_list_title;
    Typeface custom_font;
    ImageView img_cpu,img_rotate,img_trash_rotate,img_trash_done;
    RelativeLayout ryt_rotate, ryt_list,ryt_trash;
    ListView lv_apps;
    Button btn_cool;
    boolean isCleaned = false;
    AppAdapter installedAppAdapter;
    ArrayList<AppList> appArray;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan);

        custom_font = Typeface.createFromAsset(getAssets(),"fonts/LinotteRegular.ttf");   //Custom Font
        tx_title = (TextView) findViewById(R.id.tx_title);
        tx_scan = (TextView) findViewById(R.id.tx_scan);
        tx_trash = (TextView) findViewById(R.id.tx_trash);
        tx_list_title = (TextView) findViewById(R.id.tx_heating_apps);
        tx_title.setTypeface(custom_font);
        tx_scan.setTypeface(custom_font);
        tx_trash.setTypeface(custom_font);
        tx_list_title.setTypeface(custom_font);

        img_cpu = (ImageView) findViewById(R.id.img_cpu);
        img_rotate = (ImageView) findViewById(R.id.img_rotate);
        img_trash_rotate = (ImageView) findViewById(R.id.img_rotate_trash);
        img_trash_done = (ImageView) findViewById(R.id.img_done_trash);
        lv_apps = (ListView) findViewById(R.id.list_app);
        btn_cool = (Button) findViewById(R.id.btn_cool);
        btn_cool.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                clean_apps();
            }
        });

        ryt_rotate = (RelativeLayout) findViewById(R.id.ryt_rotate);
        ryt_list = (RelativeLayout) findViewById(R.id.ryt_done);
        ryt_trash = (RelativeLayout) findViewById(R.id.ryt_trash);

        //-----------Bottom Banner Ads---------------
        adView = (AdView) findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().setRequestAgent("android_studio:ad_template").build();
        adView.loadAd(adRequest);

        ObjectAnimator rotateAnimator = ObjectAnimator.ofFloat(img_rotate, View.ROTATION, new float[]{0.0F, 360.0F}).setDuration(1000L);
        rotateAnimator.setInterpolator(new LinearInterpolator());
        rotateAnimator.setRepeatCount(-1);
        rotateAnimator.start();
        list_show_handler.postDelayed(list_show,5000);
            }
    Handler list_show_handler = new Handler();
    private Runnable list_show = new Runnable() {
        public void run() {
            if(GlobalVar.nStatus == 1)
            {
                Intent newIntent = new Intent(Scan.this,Result.class);
                startActivity(newIntent);
                Scan.this.finish();
            }
            else {

//                final ActivityManager activityManager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
//                final List<ActivityManager.RunningTaskInfo> recentTasks = activityManager.getRunningTasks(Integer.MAX_VALUE);
//
//                for (int i = 0; i < recentTasks.size(); i++)
//                {
//                    Log.d("Executed app", "Application executed : " +recentTasks.get(i).baseActivity.toShortString()+ "\t\t ID: "+recentTasks.get(i).id+"");
//                }
                appArray = getInstalledApps();
                installedAppAdapter = new AppAdapter(Scan.this, appArray);
                lv_apps.setAdapter(installedAppAdapter);
                lv_apps.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
                slideGone(ryt_rotate);
                ryt_list.setVisibility(View.VISIBLE);
            }
        }
    };

    Handler trash_app_handler = new Handler();
    private Runnable trash_app = new Runnable() {
        public void run() {
            if(!isCleaned) {
                img_trash_rotate.setVisibility(View.GONE);
                img_trash_done.setVisibility(View.VISIBLE);
                tx_trash.setText("Cleaned Heating Apps");
                ObjectAnimator localObjectAnimator1 = ObjectAnimator.ofFloat(img_trash_done, View.SCALE_X, new float[]{0.5F, 1.0F, 0.8F}).setDuration(1300L);
                ObjectAnimator localObjectAnimator2 = ObjectAnimator.ofFloat(img_trash_done, View.SCALE_Y, new float[]{0.5F, 1.0F, 0.8F}).setDuration(1300L);
                AnimatorSet localAnimatorSet1 = new AnimatorSet();
                localAnimatorSet1.playTogether(new Animator[]{localObjectAnimator1, localObjectAnimator2});
                localAnimatorSet1.start();
                isCleaned = true;
                trash_app_handler.postDelayed(trash_app, 2000L);
            }
            else{
                Intent newIntent = new Intent(Scan.this,Result.class);
                startActivity(newIntent);
                Scan.this.finish();
            }
        }
    };
    public void clean_apps(){
        slideGone(ryt_list);
        ryt_trash.setVisibility(View.VISIBLE);

        ObjectAnimator localObjectAnimator1 = ObjectAnimator.ofFloat(img_trash_rotate, View.SCALE_X, new float[]{0.0F, 1.0F, 0.8F}).setDuration(1500L);
        ObjectAnimator localObjectAnimator2 = ObjectAnimator.ofFloat(img_trash_rotate, View.SCALE_Y, new float[]{0.0F, 1.0F, 0.8F}).setDuration(1500L);
        ObjectAnimator localObjectAnimator3 = ObjectAnimator.ofFloat(img_trash_rotate, View.ROTATION, new float[]{0.0F, 720.0F}).setDuration(2250L);
        localObjectAnimator3.setInterpolator(new AccelerateInterpolator());
        localObjectAnimator3.setRepeatCount(1);
        ObjectAnimator localObjectAnimator4 = ObjectAnimator.ofFloat(img_trash_rotate, View.SCALE_X, new float[]{0.8F, 0F}).setDuration(1500L);
        ObjectAnimator localObjectAnimator5 = ObjectAnimator.ofFloat(img_trash_rotate, View.SCALE_Y, new float[]{0.8F, 0F}).setDuration(1500L);


        AnimatorSet localAnimatorSet1 = new AnimatorSet();
        localAnimatorSet1.playTogether(new Animator[] { localObjectAnimator1, localObjectAnimator2 });

        AnimatorSet localAnimatorSet2 = new AnimatorSet();
        localAnimatorSet2.playTogether(new Animator[] { localObjectAnimator3 });

        AnimatorSet localAnimatorSet3 = new AnimatorSet();
        localAnimatorSet3.playTogether(new Animator[] { localObjectAnimator4, localObjectAnimator5 });

        AnimatorSet as = new AnimatorSet();
        as.playSequentially(new Animator[] { localAnimatorSet1, localAnimatorSet2, localAnimatorSet3});
        as.setStartDelay(0L);
        as.start();
        trash_app_handler.postDelayed(trash_app,7500);
    }

    //----------get Installed Applications-------------------
    private ArrayList<AppList> getInstalledApps() {
        ArrayList<AppList> res = new ArrayList<AppList>();
        List<PackageInfo> packs = getPackageManager().getInstalledPackages(0);
        for (int i = 0; i < packs.size(); i++) {
            PackageInfo p = packs.get(i);
            if ((isSystemPackage(p) == false)) {
                String strPackage = p.applicationInfo.packageName;
                String appName = p.applicationInfo.loadLabel(getPackageManager()).toString();
                Drawable icon = p.applicationInfo.loadIcon(getPackageManager());
                res.add(new AppList(appName, icon, strPackage));
            }
        }
        return res;
    }
    //------------if SystemPackage return true-------
    private boolean isSystemPackage(PackageInfo pkgInfo) {
        return ((pkgInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0) ? true : false;
    }

    public void slideGone(View view) {
        TranslateAnimation animate = new TranslateAnimation(0, 0, 0, -view.getHeight());
        animate.setDuration(500);
        animate.setFillAfter(true);
        view.startAnimation(animate);
        view.setVisibility(View.GONE);
    }

    @Override
    public void onBackPressed() {
    }
}
