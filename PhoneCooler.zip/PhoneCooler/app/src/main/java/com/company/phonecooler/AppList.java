package com.company.phonecooler;

import android.graphics.drawable.Drawable;


public class AppList {

    String name;
    String packagename;
    Drawable icon;
    boolean selected;

    public AppList(String name, Drawable icon, String strPackage) {
        this.name = name;
        this.icon = icon;
        this.packagename = strPackage;
        this.selected = false;
    }

    public String getName() {
        return name;
    }
    public String getPackage() {
        return packagename;
    }
    public Drawable getIcon() {
        return icon;
    }
    public void setSelected(boolean selected) {
        this.selected = selected;
    }
    public boolean isSelected() {
        return selected;
    }
}