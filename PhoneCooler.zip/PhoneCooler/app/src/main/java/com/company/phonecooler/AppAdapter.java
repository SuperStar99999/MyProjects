package com.company.phonecooler;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class AppAdapter extends ArrayAdapter<AppList> {

    boolean mCheckStates[];

    private final Activity context;
    //    private final String[] itemname;
//    private final Drawable[] drIcons;
    private final Boolean[] isChecked;
    ArrayList<AppList> arrayList;


    public AppAdapter(Activity context, ArrayList<AppList> mList){//String[] itemname, Drawable[] drIcon) {
        super(context, R.layout.app_list, mList);
        // TODO Auto-generated constructor stub
        mCheckStates = new boolean[mList.size()];
        arrayList = mList;
        this.context=context;
//        this.itemname=itemname;
//        this.drIcons = drIcon;

        this.isChecked = new Boolean[this.arrayList.size()];
        for(int i = 0 ; i < this.arrayList.size(); i ++)
            this.isChecked[i] = false;
    }

    public View getView(final int position, View convertView, ViewGroup parent) {

        ViewHolder viewHolder = null;
        if (convertView == null) {
            LayoutInflater inflator = context.getLayoutInflater();
            convertView = inflator.inflate(R.layout.app_list, null);
            convertView.setClickable(true);
            convertView.setFocusable(true);
            viewHolder = new ViewHolder();
            viewHolder.text = (TextView) convertView.findViewById(R.id.app_title);
            viewHolder.checkbox = (CheckBox) convertView.findViewById(R.id.checkbox);
            viewHolder.imgIcon = (ImageView) convertView.findViewById(R.id.icon);
            viewHolder.checkbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    int getPosition = (Integer) buttonView.getTag();  // Here we get the position that we have set for the checkbox using setTag.
                    arrayList.get(getPosition).setSelected(buttonView.isChecked()); // Set the value of checkbox to maintain its state.
                    mCheckStates[position] = isChecked;
                }
            });
            convertView.setTag(viewHolder);
            convertView.setTag(R.id.app_title, viewHolder.text);
            convertView.setTag(R.id.checkbox, viewHolder.checkbox);
            convertView.setTag(R.id.icon,viewHolder.imgIcon);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        viewHolder.checkbox.setTag(position); // This line is important.
        AppList apTemp = arrayList.get(position);
        viewHolder.text.setText(apTemp.getName());
        viewHolder.checkbox.setChecked(arrayList.get(position).isSelected());
        viewHolder.imgIcon.setImageDrawable(apTemp.getIcon());
        return convertView;
    }
    static class ViewHolder {
        protected TextView text;
        protected CheckBox checkbox;
        protected ImageView imgIcon;
    }
}

