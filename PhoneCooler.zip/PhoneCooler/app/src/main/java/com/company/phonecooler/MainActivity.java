package com.company.phonecooler;

import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.LimitLine;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.github.mikephil.charting.utils.Utils;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

import java.util.ArrayList;
import java.util.Random;


public class MainActivity extends Activity {
    AdView adView;
    InterstitialAd mInterstitialAd;

    Typeface custom_font;

    TextView tx_title, tx_ram, tx_ram_pro, tx_cpu, tx_cpu_pro;
    Button btn_setting, btn_scan;
    ProgressBar pb_ram, pb_cpu;
    //-------------Setting Variable-------------
    private SharedPreferences.Editor editor;
    private SharedPreferences spSetting;

    //-------------Temperature Images-----------------
    ImageView img_hundred,img_ten,img_one,img_dot,img_float,img_temp;

//    private LineChart mChart;

    private final int[] tmp_imgs = { R.drawable.temp_0, R.drawable.temp_1,R.drawable.temp_2,R.drawable.temp_3,R.drawable.temp_4,R.drawable.temp_5,R.drawable.temp_6,R.drawable.temp_7,R.drawable.temp_8,R.drawable.temp_9};

    Handler randomhandle = new Handler();
    //-------------interstitial Ads Handler------------
    Handler admobhandler = new Handler();
    Runnable serviceRunnableAdmob = new Runnable() {
        @Override
        public void run() {
            requestNewInterstitial();
        }
    };
    private void requestNewInterstitial() {
        AdRequest localAdRequest = new AdRequest.Builder().build();
        this.mInterstitialAd.loadAd(localAdRequest);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //-----------LoadSetting------------------
        this.spSetting = this.getSharedPreferences("BBSettings", 0);
        this.editor = this.spSetting.edit();
        loadSetting();

        get_resources();
        init_ads();

        final Runnable randomval = new Runnable() {
            @Override
            public void run() {
                Random rn = new Random();
                img_hundred.setImageResource(tmp_imgs[rn.nextInt(10)]);
                img_ten.setImageResource(tmp_imgs[rn.nextInt(10)]);
                img_one.setImageResource(tmp_imgs[rn.nextInt(10)]);
                img_float.setImageResource(tmp_imgs[rn.nextInt(10)]);

                update_progressbars();
                randomhandle.postDelayed(this,1000);
            }
        };
        randomhandle.postDelayed(randomval,1000);


    }
    public void get_resources(){
        custom_font = Typeface.createFromAsset(getAssets(),"fonts/LinotteRegular.ttf");   //Custom Font
        //------------Text And Button Resources-------------------
        tx_title = (TextView) findViewById(R.id.tx_title);
        tx_cpu = (TextView) findViewById(R.id.tx_cpu);
        tx_cpu_pro = (TextView) findViewById(R.id.tx_cpu_pro);
        tx_ram = (TextView) findViewById(R.id.tx_ram);
        tx_ram_pro = (TextView) findViewById(R.id.tx_ram_pro);

        btn_scan = (Button) findViewById(R.id.btn_scan_app);
        btn_setting = (Button) findViewById(R.id.btn_setting);

        pb_ram = (ProgressBar) findViewById(R.id.arc_progress_ram);
        pb_cpu = (ProgressBar) findViewById(R.id.arc_progress_cpu);


        tx_title.setTypeface(custom_font);
        tx_ram.setTypeface(custom_font);
        tx_ram_pro.setTypeface(custom_font);
        tx_cpu.setTypeface(custom_font);
        tx_cpu_pro.setTypeface(custom_font);
        btn_scan.setTypeface(custom_font);

        //--------------Get Temp Number Images---------------------
        img_hundred = (ImageView) findViewById(R.id.hundredImage);
        img_ten = (ImageView) findViewById(R.id.tenImage);
        img_one = (ImageView) findViewById(R.id.oneImage);
        img_dot = (ImageView) findViewById(R.id.dotImage);
        img_float = (ImageView) findViewById(R.id.floatImage);
        img_temp = (ImageView) findViewById(R.id.tempImage);

        //================Chart=======================
//        mChart = (LineChart) findViewById(R.id.chart1);

//        LimitLine llXAxis = new LimitLine(10f, "Index 10");
//        llXAxis.setLineWidth(4f);
//        llXAxis.enableDashedLine(10f, 10f, 0f);
//        llXAxis.setLabelPosition(LimitLine.LimitLabelPosition.RIGHT_BOTTOM);
//        llXAxis.setTextSize(10f);
//
//        XAxis xAxis = mChart.getXAxis();
//        xAxis.enableGridDashedLine(10f, 10f, 0f);
//        //xAxis.setValueFormatter(new MyCustomXAxisValueFormatter());
//        //xAxis.addLimitLine(llXAxis); // add x-axis limit line
//
//
//
//
//        LimitLine ll1 = new LimitLine(150f, "Upper Limit");
//        ll1.setLineWidth(4f);
//        ll1.enableDashedLine(10f, 10f, 0f);
//        ll1.setLabelPosition(LimitLine.LimitLabelPosition.RIGHT_TOP);
//        ll1.setTextSize(10f);
//        ll1.setTypeface(custom_font);
//
//        LimitLine ll2 = new LimitLine(-30f, "Lower Limit");
//        ll2.setLineWidth(4f);
//        ll2.enableDashedLine(10f, 10f, 0f);
//        ll2.setLabelPosition(LimitLine.LimitLabelPosition.RIGHT_BOTTOM);
//        ll2.setTextSize(10f);
//        ll2.setTypeface(custom_font);
//
//        YAxis leftAxis = mChart.getAxisLeft();
//        leftAxis.removeAllLimitLines(); // reset all limit lines to avoid overlapping lines
//        leftAxis.addLimitLine(ll1);
//        leftAxis.addLimitLine(ll2);
//        leftAxis.setAxisMaximum(200f);
//        leftAxis.setAxisMinimum(-50f);
//        //leftAxis.setYOffset(20f);
//        leftAxis.enableGridDashedLine(10f, 10f, 0f);
//        leftAxis.setDrawZeroLine(false);
//
//        // limit lines are drawn behind data (and not on top)
//        leftAxis.setDrawLimitLinesBehindData(true);
//
//        mChart.getAxisRight().setEnabled(false);

        //mChart.getViewPortHandler().setMaximumScaleY(2f);
        //mChart.getViewPortHandler().setMaximumScaleX(2f);

        // add data
//        setData(45, 100);

//        mChart.setVisibleXRange(20);
//        mChart.setVisibleYRange(20f, AxisDependency.LEFT);
//        mChart.centerViewTo(20, 50, AxisDependency.LEFT);

//        mChart.animateX(2500);
//        //mChart.invalidate();
//
//        // get the legend (only possible after setting data)
//        Legend l = mChart.getLegend();
//
//        // modify the legend ...
//        l.setForm(Legend.LegendForm.LINE);



        if(GlobalVar.isCelsius)
            img_temp.setImageResource(R.drawable.ic_temp_celsius);
        else
            img_temp.setImageResource(R.drawable.ic_temp_f);

        btn_setting.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                Intent newIntent = new Intent(MainActivity.this,Setting.class);
                startActivity(newIntent);
            }
        });

        btn_scan.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                Intent newIntent = new Intent(MainActivity.this,Scan.class);
                startActivity(newIntent);
            }
        });

    }

    public void init_ads(){
        //-----------Bottom Banner Ads---------------
        adView = (AdView) findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().setRequestAgent("android_studio:ad_template").build();
        adView.loadAd(adRequest);

        //-------------Interstitial Ads-----------------
        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId("ca-app-pub-8415102332993671/5295325546");
        mInterstitialAd.setAdListener(new AdListener()
        {
            public void onAdClosed()
            {
                admobhandler.postDelayed(serviceRunnableAdmob,60000);
            }
            public void onAdLoaded()
            {
                mInterstitialAd.show();
            }
        });
        requestNewInterstitial();
    }

    public void update_progressbars(){
        Random rn = new Random();
        int nCpu= rn.nextInt(100);
        tx_cpu_pro.setText(nCpu+"%");
        if(android.os.Build.VERSION.SDK_INT >= 11){
            // will update the "progress" propriety of seekbar until it reaches progress
            ObjectAnimator animation = ObjectAnimator.ofInt(pb_cpu, "progress", nCpu);
            animation.setDuration(500); // 0.5 second
            animation.setInterpolator(new DecelerateInterpolator());
            animation.start();
        }
        else
            pb_cpu.setProgress(nCpu); // no animation on Gingerbread or lower

        int nRam = rn.nextInt(100);
        tx_ram_pro.setText(nRam+"%");
        if(android.os.Build.VERSION.SDK_INT >= 11){
            // will update the "progress" propriety of seekbar until it reaches progress
            ObjectAnimator animation = ObjectAnimator.ofInt(pb_ram, "progress", nRam);
            animation.setDuration(500); // 0.5 second
            animation.setInterpolator(new DecelerateInterpolator());
            animation.start();
        }
        else
            pb_cpu.setProgress(nRam); // no animation on Gingerbread or lower
    }
/*
    private void setData(int count, float range) {

        ArrayList<Entry> values = new ArrayList<Entry>();

        for (int i = 0; i < count; i++) {

            float val = (float) (Math.random() * range) + 3;
            values.add(new Entry(i, val, getResources().getDrawable(R.drawable.snowflakes)));
        }

        LineDataSet set1;

        if (mChart.getData() != null &&
                mChart.getData().getDataSetCount() > 0) {
            set1 = (LineDataSet)mChart.getData().getDataSetByIndex(0);
            set1.setValues(values);
            mChart.getData().notifyDataChanged();
            mChart.notifyDataSetChanged();
        } else {
            // create a dataset and give it a type
            set1 = new LineDataSet(values, "DataSet 1");

//            set1.setDrawIcons(false);

            // set the line to be drawn like this "- - - - - -"
            set1.enableDashedLine(10f, 5f, 0f);
            set1.enableDashedHighlightLine(10f, 5f, 0f);
            set1.setColor(Color.BLACK);
            set1.setCircleColor(Color.BLACK);
            set1.setLineWidth(1f);
            set1.setCircleRadius(3f);
            set1.setDrawCircleHole(false);
            set1.setValueTextSize(9f);
            set1.setDrawFilled(true);
            set1.setFormLineWidth(1f);
            set1.setFormLineDashEffect(new DashPathEffect(new float[]{10f, 5f}, 0f));
            set1.setFormSize(15.f);

            if (Utils.getSDKInt() >= 18) {
                // fill drawable only supported on api level 18 and above
                Drawable drawable = ContextCompat.getDrawable(this, R.drawable.fade_red);
                set1.setFillDrawable(drawable);
            }
            else {
                set1.setFillColor(Color.BLACK);
            }

            ArrayList<ILineDataSet> dataSets = new ArrayList<ILineDataSet>();
            dataSets.add(set1); // add the datasets

            // create a data object with the datasets
            LineData data = new LineData(dataSets);

            // set data
            mChart.setData(data);
        }
    }
    */

    boolean doubleBackToExitPressedOnce = false;
    @Override
    public void onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            android.os.Process.killProcess(android.os.Process.myPid());
            System.exit(1);
        }

        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "Press BACK again to exit", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                doubleBackToExitPressedOnce=false;
            }
        }, 2000);
    }

    @Override
    protected void onResume() {
        Log.i("onresume","onresume");
        if(GlobalVar.isCelsius)
            img_temp.setImageResource(R.drawable.ic_temp_celsius);
        else
            img_temp.setImageResource(R.drawable.ic_temp_f);
        super.onResume();
    }

    @Override
    protected void onRestart() {
        Log.i("restart","restart");
        super.onRestart();
    }

    public void loadSetting(){
        GlobalVar.isReminder = this.spSetting.getBoolean("isReminder", true);
        GlobalVar.isCelsius = this.spSetting.getBoolean("isCelius", true);
    }
}
