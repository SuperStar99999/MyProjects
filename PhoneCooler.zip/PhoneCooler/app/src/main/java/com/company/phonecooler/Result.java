package com.company.phonecooler;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.NativeExpressAdView;


public class Result extends AppCompatActivity {
    Button btnRate;
    NativeExpressAdView adView_middle;
    int nCounter = 5;

    TextView tx_timer;
    TextView tx_cooled;
    LinearLayout lyt_counter,lyt_cooled;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setDisplayShowTitleEnabled(true);

        tx_timer = (TextView) findViewById(R.id.tx_timer);
        tx_cooled = (TextView) findViewById(R.id.tx_cooled);
        lyt_cooled = (LinearLayout) findViewById(R.id.lyt_cooled);
        lyt_counter = (LinearLayout) findViewById(R.id.lyt_counter);

        btnRate = (Button) findViewById(R.id.btnrate);
        btnRate.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                RateUs();
            }
        });

        adView_middle = (NativeExpressAdView)findViewById(R.id.adView_middle);
        String android_id = Settings.Secure.getString(this.getContentResolver(),Settings.Secure.ANDROID_ID);
        AdRequest request = new AdRequest.Builder().addTestDevice(android_id).build();
        adView_middle.loadAd(request);
        if(GlobalVar.nStatus == 1) {
            tx_timer.setText("Phone has been cooled");
        }
        else {
            timerHandler.postDelayed(timerCool, 1000);
        }
    }
    public void RateUs()
    {
        Uri uri = Uri.parse("market://details?id=" + this.getPackageName());
        Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
        goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY | Intent.FLAG_ACTIVITY_NEW_DOCUMENT | Intent.FLAG_ACTIVITY_MULTIPLE_TASK);

        try {
            startActivity(goToMarket);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + this.getPackageName())));
        }
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        this.finish();
        return true;
    }
    Handler timerHandler = new Handler();
    Runnable timerCool = new Runnable() {
        @Override
        public void run() {
            if(nCounter>0)
            {
                nCounter--;
                tx_timer.setText(nCounter+"s until phone cooled.");
                timerHandler.postDelayed(this,1000);
            }
            if (nCounter==0)
            {
                GlobalVar.nStatus = 1;
                nCounter = -1;
                slideGone(lyt_counter);
                tx_cooled.setText("Dropped "+"℃");
                lyt_cooled.setVisibility(View.VISIBLE);
            }
        }
    };

    public void slideGone(View view) {
        TranslateAnimation animate = new TranslateAnimation(0, 0, 0, -view.getHeight());
        animate.setDuration(500);
        animate.setFillAfter(true);
        view.startAnimation(animate);
        view.setVisibility(View.GONE);
    }
}
