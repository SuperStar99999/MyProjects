<?php
$response = array();
$response["success"] = "false";
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "timer";

$data = json_decode(file_get_contents('php://input'), true);
$appusername = $data["username"];
$apppassword = $data["password"];
$sql = "";
// Create connection

$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM schedule";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $response["success"] = "true";
    $response["message"] = "Exist";
    $rows = array();
    while($r = mysqli_fetch_assoc($result)) {
        $rows[] = $r;
    }
    $response["data"] = $rows;
} else {
    $response["success"] = "false";
    $response["message"] = "No user found";
}
$conn->close();
// echoing JSON response
echo json_encode($response);


