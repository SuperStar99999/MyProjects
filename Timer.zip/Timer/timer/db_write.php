<?php
$response = array();
$response["success"] = "false";
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "timer";

$data = json_decode(file_get_contents('php://input'), true);
$appusername = $data["username"];
$apppassword = $data["password"];

$apptitle1 = $data["title1"];
$apptitle2 = $data["title2"];
$apptitle3 = $data["title3"];
$apptitle4 = $data["title4"];
$apptitle5 = $data["title5"];

$apptime1 = $data["time1"];
$apptime2 = $data["time2"];
$apptime3 = $data["time3"];
$apptime4 = $data["time4"];
$apptime5 = $data["time5"];

$sql = "";
// Create connection

$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "DELETE FROM schedule WHERE username='$appusername' AND password='$apppassword'";
if ($conn->query($sql) === TRUE) {
    echo "Record deleted successfully";
} else {
    echo "Error deleting record: " . $conn->error;
}

$sql = "INSERT INTO schedule (username, password, title, time) VALUES ('$appusername', '$apppassword', '$apptitle1', '$apptime1');";
$sql.= "INSERT INTO schedule (username, password, title, time) VALUES ('$appusername', '$apppassword', '$apptitle2', '$apptime2');";
$sql.= "INSERT INTO schedule (username, password, title, time) VALUES ('$appusername', '$apppassword', '$apptitle3', '$apptime3');";
$sql.= "INSERT INTO schedule (username, password, title, time) VALUES ('$appusername', '$apppassword', '$apptitle4', '$apptime4');";
$sql.= "INSERT INTO schedule (username, password, title, time) VALUES ('$appusername', '$apppassword', '$apptitle5', '$apptime5');";
if (mysqli_multi_query($conn, $sql)) {
    echo "New records created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

$conn->close();
// echoing JSON response
echo json_encode($response);


