package com.example.admin.timerapp;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.os.Handler;
import android.os.IBinder;
import android.os.SystemClock;
import android.util.Log;

import java.util.Calendar;

public class silentmode extends Service{
    Handler timerHandler;
    Runnable silencerunnable;
    AudioManager am;
    boolean flag = false;
    int ncount = 0;
    @Override
    public IBinder onBind(Intent arg0) {
        // TODO Auto-generated method stub
        Log.i("start","onBind");
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // TODO Auto-generated method stub
        Log.i("start","onStartCommand");
        timerHandler = new Handler();
        am= (AudioManager) getBaseContext().getSystemService(Context.AUDIO_SERVICE);
        silencerunnable = new Runnable() {
            @Override
            public void run() {
                Log.i("Background Service","Background Service");
                Calendar rightNow = Calendar.getInstance();
                int currentHour = rightNow.get(Calendar.HOUR_OF_DAY);
                int currentMin = rightNow.get(Calendar.MINUTE);
                Log.i("timer",""+currentHour+":"+currentMin);
                String strCurrent = ""+currentHour+currentMin;
                for(int i = 0 ; i < 5; i++)
                {
                    if(strCurrent.equals(GlobalVar.strTime[i]))
                    {
                        am.setRingerMode(AudioManager.RINGER_MODE_SILENT);
                        flag = true;
                    }
                }
                if(flag){
                    ncount ++;
                }

                if(ncount > 200){
                    am.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
                    ncount = 0;
                }
                timerHandler.postDelayed(silencerunnable, 3000);
            }
        };
        timerHandler.postDelayed(silencerunnable, 100);
        return START_STICKY;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        // TODO Auto-generated method stub
        Intent restartService = new Intent(getApplicationContext(),
                this.getClass());
        restartService.setPackage(getPackageName());
        PendingIntent restartServicePI = PendingIntent.getService(
                getApplicationContext(), 1, restartService,
                PendingIntent.FLAG_ONE_SHOT);

        //Restart the service once it has been killed android

        AlarmManager alarmService = (AlarmManager)getApplicationContext().getSystemService(Context.ALARM_SERVICE);
        alarmService.set(AlarmManager.ELAPSED_REALTIME, SystemClock.elapsedRealtime() +100, restartServicePI);
    }

    @Override
    public void onCreate() {
        // TODO Auto-generated method stub
        Log.i("start","onCreate");
        super.onCreate();
        //start a separate thread and start listening to your network object
    }
}
