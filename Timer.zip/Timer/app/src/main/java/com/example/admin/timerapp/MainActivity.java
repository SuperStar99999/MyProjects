package com.example.admin.timerapp;

import android.app.ActivityManager;
import android.app.Dialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.IBinder;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.Spinner;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    Button btn_save;
    Button btn_login;
    Spinner sp_users;
    CustomLoadingDialog dialog;
    LinearLayout lyt_first, lyt_second, lyt_third, lyt_fourth, lyt_fivth;
    ArrayAdapter<String> spinnerAdapter;

    TextView txtitle[] = new TextView[5];
    TextView txtime[] = new TextView[5];

    String strTitle[] = new String[5];
    String strTime[] = new String[5];

    JSONArray jsData;
    String[] strUserlist;
    String[] strPwdlist;
    int nUsertype = 0;
    String strUsername = "Admin";
    String strPassword ="123";

    silentmode myService;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if(getIntent().getExtras() != null) {
            nUsertype = getIntent().getExtras().getInt("usertype");
            strUsername = getIntent().getExtras().getString("username");
            strPassword = getIntent().getExtras().getString("password");
        }
        dialog = new CustomLoadingDialog(MainActivity.this, R.style.AppCompatAlertDialogStyle);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.setCancelable(false);

        btn_save = (Button) findViewById(R.id.btn_save);
        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateschedule();
            }
        });
        btn_login = (Button) findViewById(R.id.btn_login);
        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent newInstent = new Intent(MainActivity.this,Login.class);
                startActivity(newInstent);
                MainActivity.this.finish();
            }
        });
//        sp_users = (Spinner) findViewById(R.id.usernames);

        txtitle[0] = (TextView) findViewById(R.id.tx_first);
        txtitle[1] = (TextView) findViewById(R.id.tx_second);
        txtitle[2] = (TextView) findViewById(R.id.tx_third);
        txtitle[3] = (TextView) findViewById(R.id.tx_fourth);
        txtitle[4] = (TextView) findViewById(R.id.tx_fivth);

        txtime[0] = (TextView) findViewById(R.id.tm_first);
        txtime[1] = (TextView) findViewById(R.id.tm_second);
        txtime[2] = (TextView) findViewById(R.id.tm_third);
        txtime[3] = (TextView) findViewById(R.id.tm_fourth);
        txtime[4] = (TextView) findViewById(R.id.tm_fivth);

        lyt_first = (LinearLayout) findViewById(R.id.lyt_first);
        lyt_second = (LinearLayout) findViewById(R.id.lyt_second);
        lyt_third = (LinearLayout) findViewById(R.id.lyt_third);
        lyt_fourth = (LinearLayout) findViewById(R.id.lyt_fourth);
        lyt_fivth = (LinearLayout) findViewById(R.id.lyt_fivth);


        if(nUsertype == 1) {
            forAdmin();
        }
        getByUsername();
        if(isMyServiceRunning(silentmode.class)) {
            stopService(new Intent(this, silentmode.class));
        }
        Intent intent = new Intent(MainActivity.this, silentmode.class);
        startService(intent);
    }
    public void getByUsername(){
        JSONObject userinfo = new JSONObject();
        try {
            userinfo.put("username", strUsername);
            userinfo.put("password", strPassword);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestQueue queue = Volley.newRequestQueue(MainActivity.this);

        JsonObjectRequest logReq = new JsonObjectRequest(Request.Method.POST, GlobalVar.url + "db_read.php", userinfo, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                dialog.dismiss();
                try {
                    if(response.getString("success").equals("true")){
                        jsData = response.getJSONArray("data");
                        {
                            for(int i = 0; i < jsData.length(); i ++){
                                JSONObject jsObj = new JSONObject();
                                jsObj = (JSONObject) jsData.getJSONObject(i);
                                Log.i("dddd",jsObj.toString());
                                strTitle[i] = jsObj.getString("title");
                                strTime[i] = jsObj.getString("time");
                                GlobalVar.strTitle[i] = jsObj.getString("title");
                                GlobalVar.strTime[i] = jsObj.getString("time");
                            }
                        }
                        Intent intent = new Intent(MainActivity.this, silentmode.class);
                        startService(intent);
                        updateview();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.i("response error",error.toString());
                dialog.dismiss();
            }
        });
        queue.add(logReq);
    }

    private boolean isMyServiceRunning(Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    public void updateschedule(){
        GlobalVar.strTitle = strTitle;
        GlobalVar.strTime = strTime;

        JSONObject userinfo = new JSONObject();
        try {

            userinfo.put("username", strUsername);
            userinfo.put("password", strPassword);

            userinfo.put("title1", strTitle[0]);
            userinfo.put("title2", strTitle[1]);
            userinfo.put("title3", strTitle[2]);
            userinfo.put("title4", strTitle[3]);
            userinfo.put("title5", strTitle[4]);

            userinfo.put("time1", strTime[0]);
            userinfo.put("time2", strTime[1]);
            userinfo.put("time3", strTime[2]);
            userinfo.put("time4", strTime[3]);
            userinfo.put("time5", strTime[4]);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestQueue queue = Volley.newRequestQueue(MainActivity.this);

        JsonObjectRequest logReq = new JsonObjectRequest(Request.Method.POST, GlobalVar.url + "db_write.php", userinfo, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                dialog.dismiss();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.i("response error",error.toString());
                dialog.dismiss();
            }
        });
        queue.add(logReq);
    }

    public void forAdmin(){
        btn_save.setVisibility(View.VISIBLE);

        btn_login.setVisibility(View.INVISIBLE);
        lyt_first.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nameTimeDlg(0);
            }
        });
        lyt_second.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nameTimeDlg(1);
            }
        });
        lyt_third.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nameTimeDlg(2);
            }
        });
        lyt_fourth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nameTimeDlg(3);
            }
        });
        lyt_fivth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nameTimeDlg(4);
            }
        });


//        spinnerAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, android.R.id.text1);
//        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//        sp_users.setAdapter(spinnerAdapter);
//        spinnerAdapter.notifyDataSetChanged();
//        sp_users.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//            @Override
//            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
//                Log.i("position:::",""+strUserlist[position]);
//                strUsername = strUserlist[position];
//                strPassword = strPwdlist[position];
//                int j = 0;
//                for(int i = 0; i < jsData.length(); i ++){
//                    JSONObject jsObj = new JSONObject();
//                    try {
//                        jsObj = (JSONObject) jsData.getJSONObject(i);
//                    } catch (JSONException e) {
//                        e.printStackTrace();
//                    }
//
//                    try {
//                        if(jsObj.getString("username").equals(strUserlist[position])){
//                            strTitle[j] = jsObj.getString("title");
//                            strTime[j] = jsObj.getString("time");
//                            j++;
//                        }
//                    } catch (JSONException e) {
//                        e.printStackTrace();
//                    }
//                }
//
//                updateview();
//            }
//            @Override
//            public void onNothingSelected(AdapterView<?> parentView) {
//                // your code here
//            }
//
//        });
    }
    public void updateview(){
        for(int i = 0; i < 5; i ++)
        {
            txtitle[i].setText(strTitle[i]);
            String str = strTime[i].substring(0,2) + ":" + strTime[i].substring(2,4);
            txtime[i].setText(str);
        }
    }
    public void nameTimeDlg(final int index){
        final Dialog dpolling = new Dialog(this);
        dpolling.setTitle("Schedule Info");
        dpolling.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dpolling.setContentView(R.layout.info);
        Button btn_ok = (Button) dpolling.findViewById(R.id.btn_login);
        final EditText et_title = (EditText) dpolling.findViewById(R.id.title);
        final NumberPicker np1 = (NumberPicker) dpolling.findViewById(R.id.numberPicker1);
        final NumberPicker np2 = (NumberPicker) dpolling.findViewById(R.id.numberPicker2);
        final NumberPicker np3 = (NumberPicker) dpolling.findViewById(R.id.numberPicker3);
        final NumberPicker np4 = (NumberPicker) dpolling.findViewById(R.id.numberPicker4);
        np1.setMaxValue(2); // max value 100
        np1.setMinValue(0);   // min value 2
        np1.setWrapSelectorWheel(true);

        np2.setMaxValue(9); // max value 100
        np2.setMinValue(0);   // min value 2
        np2.setWrapSelectorWheel(true);

        np3.setMaxValue(5); // max value 100
        np3.setMinValue(0);   // min value 2
        np3.setWrapSelectorWheel(true);

        np4.setMaxValue(9); // max value 100
        np4.setMinValue(0);   // min value 2
        np4.setWrapSelectorWheel(true);
        int hr10,hr1,min10,min1;
        String strtitle = "";
        String strtime = "";

        strtitle = strTitle[index];
        strtime = strTime[index];

        hr10 = Integer.parseInt(strtime)/1000;
        hr1 = (Integer.parseInt(strtime)%1000)/100;
        min10 = (Integer.parseInt(strtime)%100)/10;
        min1 = (Integer.parseInt(strtime)%10);
        et_title.setText(strtitle);
        np1.setValue(hr10);
        np2.setValue(hr1);
        np3.setValue(min10);
        np4.setValue(min1);

        btn_ok.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                String strtime ="" + np1.getValue() + np2.getValue() + np3.getValue() + np4.getValue();
                String strtitle= et_title.getText().toString();
                strTime[index] = strtime;
                strTitle[index] = strtitle;
                updateview();
                dpolling.dismiss();
            }
        });
        dpolling.show();
    }
}
