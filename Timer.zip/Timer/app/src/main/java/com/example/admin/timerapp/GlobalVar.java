package com.example.admin.timerapp;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Created by JJJHHHSSS on 1/14/2017.
 */

public class GlobalVar {
    public static String url = "http://192.168.3.5/timer/";
    public static String strTitle[] = new String[5];
    public static String strTime[] = new String[5];

    public void GlobalVar() {
        strTime = new String[5];
        strTitle = new String[5];
        url = "http://192.168.3.5/timer/";
    }
}