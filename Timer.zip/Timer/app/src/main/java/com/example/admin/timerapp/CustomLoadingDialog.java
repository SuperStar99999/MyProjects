package com.example.admin.timerapp;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;

public class CustomLoadingDialog extends ProgressDialog {
    public CustomLoadingDialog(Context context, int appCompatAlertDialogStyle) {
        super(context);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.loading);
    }
}