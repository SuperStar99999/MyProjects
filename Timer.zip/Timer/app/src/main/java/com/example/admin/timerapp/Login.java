package com.example.admin.timerapp;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Login extends AppCompatActivity {
    EditText et_username, et_pwd;
    Button btn_login;
    String strUsername = "";
    String strPwd = "";
    CustomLoadingDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        dialog = new CustomLoadingDialog(Login.this, R.style.AppCompatAlertDialogStyle);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.setCancelable(false);
        et_username = (EditText) findViewById(R.id.username);
        et_pwd= (EditText) findViewById(R.id.password);
        btn_login = (Button) findViewById(R.id.btn_login);

        if (isMyServiceRunning(silentmode.class)) {
            stopService(new Intent(this, silentmode.class));
        }

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                strUsername = et_username.getText().toString();
                strPwd = et_pwd.getText().toString();
                if((strUsername.length()!=0)&&(strPwd.length()!=0))
                {
                    auth();
                }
                else{
                    Context context = getApplicationContext();
                    Toast toast = Toast.makeText(context, "Input Correct Username and Password", Toast.LENGTH_SHORT);
                    toast.show();
                }
            }
        });

    }

    private boolean isMyServiceRunning(Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    public void auth(){
        dialog.show();
        JSONObject userinfo = new JSONObject();
        try {
            userinfo.put("username", strUsername);
            userinfo.put("password", strPwd);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestQueue queue = Volley.newRequestQueue(Login.this);

        String strurl = GlobalVar.url;
        strurl += "db_auth.php";
        Log.i("url",strurl);
        JsonObjectRequest logReq = new JsonObjectRequest(Request.Method.POST, strurl, userinfo, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                dialog.dismiss();
                try {
                    if(response.getString("success").equals("true")){
                        Intent newIntent = new Intent(Login.this, MainActivity.class);
                        newIntent.putExtra("usertype",1);
                        newIntent.putExtra("username", strUsername);
                        newIntent.putExtra("password", strPwd);
                        startActivity(newIntent);
                        Login.this.finish();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.i("response error",error.toString());
                dialog.dismiss();
            }
        });
        queue.add(logReq);
    }
}
